Ce jeu fonctionne sur macOS et Linux.
Compiler avec la commande "make". Cela génère l'exécutable final, nommé "main".
Pour compiler et lancer le jeu, lancer la commande "make test".
